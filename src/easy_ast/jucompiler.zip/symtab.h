typedef struct _symtab{
char *name;
int value;
}symtab;


